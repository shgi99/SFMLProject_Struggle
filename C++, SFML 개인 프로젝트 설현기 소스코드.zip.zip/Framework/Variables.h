#pragma once

class Variables
{
public:
	static bool isDrawHitBox;
	static Languages currentLang;
};